# Arquivo cliente.py: define a classe Cliente

# Definindo a classe Cliente
class Cliente:
    def __init__(self, nome, email, idade, saldo):
        # Atributos do cliente
        self.nome = nome        # Nome do cliente
        self.email = email      # Email do cliente
        self.idade = idade      # Idade do cliente
        self.saldo = saldo      # Saldo disponível para compras
        self.compras = []       # Lista para armazenar os produtos comprados

    def __str__(self):
        # Representação do objeto como string (exibido com print)
        return f"{self.nome} ({self.email})"

    def adicionar_compra(self, item, valor):
        # Método para adicionar uma compra
        if self.saldo >= valor:                     # Verifica se o saldo é suficiente
            self.compras.append(item)               # Adiciona o item na lista de compras
            self.saldo -= valor                     # Subtrai o valor do saldo
            print(f"Compra realizada: {item} por R${valor:.2f}")
        else:
            # Mensagem caso o saldo seja insuficiente
            print(f"Saldo insuficiente para comprar {item}.")

    def exibir_compras(self):
        # Método para exibir todos os produtos comprados
        if self.compras:
            print("Compras realizadas:")
            for item in self.compras:               # Para cada item na lista de compras
                print(f"- {item}")                  # Mostra o item
        else:
            print("Nenhuma compra realizada ainda.")  # Caso a lista esteja vazia
